import openai
import os
from dotenv import load_dotenv
import textstat

# Robustly load environment variables, handling files saved with non-UTF-8 encodings (e.g., Notepad UTF-16)
try:
    load_dotenv()
except UnicodeDecodeError:
    for _encoding in ("utf-16", "utf-16-le", "utf-16-be", "utf-8-sig"):
        try:
            load_dotenv(encoding=_encoding, override=True)
            break
        except UnicodeDecodeError:
            continue
openai_api_key = os.getenv("OPENAI_API_KEY")
client = openai.OpenAI(api_key=openai_api_key)


def call_gpt(prompt: str):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are BrandBot, a helpful content assistant for Dimensions."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
        max_tokens=400,
    )
    return response.choices[0].message.content.strip()


def analyze_readability(text: str):
    sentences = textstat.sentence_count(text)
    words = textstat.lexicon_count(text, removepunct=True)
    avg_sentence_length = words / sentences if sentences > 0 else 0
    return {
        "grade_level": round(textstat.flesch_kincaid_grade(text), 2),
        "sentence_length": round(avg_sentence_length, 2)
    }
