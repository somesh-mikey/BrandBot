from fastapi import FastAPI, HTTPException
from models import PromptRequest, GPTResponse
from gpt_handler import call_gpt, analyze_readability
from prompt_stack import load_business_dna, build_full_prompt
from utils import extract_sections
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="BrandBot API", description="AI-powered content generation for Dimensions")

@app.get("/")
def read_root():
    return {"message": "BrandBot API is running! Use /docs for API documentation."}

@app.get("/business")
def list_businesses():
    """List available business IDs."""
    from json import load
    try:
        with open("data/business_dna.json", "r") as f:
            data = load(f)
        return {"available_business_ids": list(data.keys())}
    except Exception as e:
        logger.error(f"Error reading business DNA: {e}")
        raise HTTPException(status_code=500, detail="Failed to read business configurations")

@app.get("/business/{business_id}")
def get_business_info(business_id: str):
    """Get business DNA information for a specific business ID"""
    dna = load_business_dna(business_id)
    if not dna:
        raise HTTPException(status_code=404, detail=f"Business ID '{business_id}' not found")
    return {"business_id": business_id, "dna": dna}

@app.post("/generate", response_model=GPTResponse)
def generate_content(req: PromptRequest):
    """Generate content based on prompt and business DNA"""
    try:
        logger.info(f"Received request: business_id={req.business_id}, prompt={req.prompt[:50]}...")
        
        # Validate business_id exists
        dna = load_business_dna(req.business_id)
        if not dna:
            raise HTTPException(status_code=404, detail=f"Business ID '{req.business_id}' not found")
        
        # Build the full prompt
        full_prompt = build_full_prompt(req.prompt, dna)
        logger.info(f"Built prompt with {len(full_prompt)} characters")
        
        # Call GPT
        gpt_output = call_gpt(full_prompt)
        logger.info(f"Received GPT response: {len(gpt_output)} characters")
        
        # Extract sections
        content, rationale, suggestions = extract_sections(gpt_output)
        
        # Analyze readability
        readability = analyze_readability(content)
        logger.info(f"Readability analysis: {readability}")
        
        # Create response
        response = GPTResponse(
            generated_content=content,
            rationale=rationale,
            marketing_suggestions=suggestions,
            readability_score=readability
        )
        
        logger.info("Successfully generated response")
        return response
        
    except HTTPException as e:
        # Re-raise FastAPI HTTP errors (e.g., 404 for unknown business_id)
        raise e
    except Exception as e:
        logger.error(f"Error in generate_content: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "BrandBot API"}
