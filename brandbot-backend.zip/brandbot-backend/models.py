from pydantic import BaseModel

class PromptRequest(BaseModel):
    prompt: str
    business_id: str

class GPTResponse(BaseModel):
    generated_content: str
    rationale: str
    marketing_suggestions: str
    readability_score: dict
